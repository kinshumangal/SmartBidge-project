# SPS-9086-chatbot-to-shop-for-essentials-during-pandemic-using-Watson-Assistant
chatbot to shop for essentials during pandemic using Watson Assistant 
Youtube Link - https://youtu.be/67Q_nImg0aQ
Youtube Link - https://youtu.be/y77rR4ATfv0
Web-Chat Link - https://web-chat.global.assistant.watson.cloud.ibm.com/preview.html?region=eu-gb&integrationID=685f8ea8-bb23-498a-9f7f-76a930f854f7&serviceInstanceID=b9ae9b0f-3600-446a-aff4-fe56e4a72d47
Node-Red Link - https://node-red-dkgcs-2021-03-15.eu-gb.mybluemix.net/ui
